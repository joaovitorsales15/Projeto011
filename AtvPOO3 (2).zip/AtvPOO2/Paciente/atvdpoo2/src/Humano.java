public class Humano {
    String nome;
    String rg;
    String endereco;
    String profissao;
    String dataNascimento;

    Humano(String n, String r, String e, String p, String d){
        nome = n;
        rg = r;
        endereco = e;
        profissao = p;
        dataNascimento = d;
    }


}
