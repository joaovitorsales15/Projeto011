import java.util.Scanner;

public class UsaHumano {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digite seu nome:");
        String nome = teclado.nextLine();

        System.out.println("Digite seu rg:");
        String rg = teclado.nextLine();

        System.out.println("Digite seu endereco:");
        String endereco = teclado.nextLine();

        System.out.println("Digite sua profissao:");
        String profissao = teclado.nextLine();

        System.out.println("Digite sua data de Nascimento");
        String dataNascimento = teclado.nextLine();

        System.out.println(" Nome: " + nome + " \nRG: " + rg + " \nEndereco: " + endereco +
                "\n Profissao: " + profissao + " \ndataNascimento: " + dataNascimento);
    }
}
