import java.util.Scanner;

public class UsaProduto {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        System.out.println("Escreva o nome da marca");
        String marca = teclado.nextLine();

        System.out.println("Digite o nome do fabricante");
        String fabricante = teclado.nextLine();

        System.out.println("Digite o codigo de barras");
        String cod_barras = teclado.nextLine();

        System.out.println("Digite o preco");
        String preco = teclado.nextLine();

        System.out.println(" Nome da marca: " + marca + " \nFabricante:" + fabricante +
                " \nCodigo de barras: " + cod_barras + " \nPreco do produto:" + preco);

    }
}
